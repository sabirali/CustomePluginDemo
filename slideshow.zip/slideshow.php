<?php
		/*
		Plugin Name: Slideshow	
		Plugin URI: http://www.softqube.co.in
		Description: Plugin for Home Page Slideshow
		Author: Softqube
		Version: 1.0
		Author URI: http://www.softqube.co.in
		*/
		
	function slideshow_admin() {  
  			include('slideshow_admin.php');  
			}  
		
	function slideshow_admin_actions() {
	
	add_options_page("Slideshow", "Slideshow", 1, "slideshow_admin", "slideshow_admin");  

		}
		add_action('admin_menu', 'slideshow_admin_actions');
	function devpress_remove_menus() {

	remove_menu_page( 'slideshow_admin.php' );

}
	?>
