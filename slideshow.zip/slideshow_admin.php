<style>
.widefat { width: 99%;}
.wrap{float:left;}
.widefatdiv{margin:10px; float:right;}
.widefatdiv a{padding:5px; background:#f7f7f7; text-decoration:none; margin:5px ;}
.suc_msg{margin:7px auto; width:500px; text-align:center; color:green; border:1px solid green; padding:5px;}
.gapimenu th{ background:#3b3b3b; padding:5px 25px;}
.gapimenu th a{ color:#fff; text-decoration:none;}
.gapimenu .selected a{ color:#3b3b3b; text-decoration:none;}
.gapimenu .selected{ background:#ccc;}
.gapimenu a:hover{text-decoration:underline;} 
</style>
<?php
	
	if(isset($_POST['add']))
	{
		$image_name = '';
		if($_FILES["slideshow_photo"]["name"] != '')
		{
			$image_name = rand().$_FILES["slideshow_photo"]["name"];
			
			copy($_FILES["slideshow_photo"]["tmp_name"],"../wp-content/themes/softqube/images/slider/".$image_name);
		}
		$sTitle = $_POST['sTitle'];
		$sSortorder = $_POST['sSortorder'];
		$sql = "insert into wp_slideshow (`sImage`, `sTitle`,`sSortorder`) values ('".$image_name."', '".$sTitle."', '".$sSortorder."')";
		$res = mysql_query($sql);
		if($res)
		{
			echo "<script>document.location='options-general.php?page=slideshow_admin&msg=2'</script>";
		}
		else
		{
			$msg = "Error!";
		}
	}
	if(isset($_POST['Update']))
	{
		$id = $_GET['id'];
		$image_name = $_POST['OldImage'];
		$OldImage = $_POST['OldImage'];
		if($_FILES["slideshow_photo"]["name"] != '')
		{
			if(is_file("../wp-content/themes/softqube/images/slider/".$OldImage)) {		unlink("../wp-content/themes/softqube/images/slider/".$OldImage);	}
			$image_name = rand().$_FILES["slideshow_photo"]["name"];
			
			copy($_FILES["slideshow_photo"]["tmp_name"],"../wp-content/themes/softqube/images/slider/".$image_name);
		}
		$sTitle = $_POST['sTitle'];
		$sSortorder = $_POST['sSortorder'];
		$sql = "Update wp_slideshow set `sImage` = '".$image_name."', `sTitle` = '".$sTitle."',`sSortorder` = '".$sSortorder."' where  sId = $id ";
		$res = mysql_query($sql);
		if($res)
		{
			echo "<script>document.location='options-general.php?page=slideshow_admin&msg=1'</script>";
		}
		else
		{
			$msg = "Error!";
		}
	}
	
	if($_GET['action'] == 'delete')
	{
		$id = $_GET['id'];
		
		$sqlg = "SELECT * FROM wp_slideshow where sId = $id ";
		$resg = mysql_query($sqlg);
		$rowg = mysql_fetch_array($resg);
		$image_name = $rowg['sImage'];
		
		if(is_file("../wp-content/themes/softqube/images/slider/".$image_name)) {		unlink("../wp-content/themes/softqube/images/slider/".$image_name);	}
		
		$res = mysql_query("DELETE FROM wp_slideshow where sId = $id");
		if($res)
		{
			echo "<script>document.location='options-general.php?page=slideshow_admin&msg=3'</script>";
		}
		else
		{
			$msg = "Error!";
		}
	}
?>

<div class="wrap" style="float:none;">
	<h2>Home Page Slideshow
    <a class="add-new-h2" href="options-general.php?page=slideshow_admin&action=add">Add New</a></h2>

</div>
<?php if(isset($_GET['action']) && ($_GET['action'] == 'edit')){ 
$id = $_GET['id'];
$sqlsel = "select * from wp_slideshow where sId = $id ";
$ressel = mysql_query($sqlsel);
$rowsel = mysql_fetch_array($ressel);
$sImage = $rowsel['sImage'];
$sTitle = $rowsel['sTitle'];
$sSortorder = $rowsel['sSortorder'];
?>
<hr>
<form name="upload" action="" method="post" enctype="multipart/form-data">
	<table cellspacing="5" cellpadding="5">
		<tr><td>Title</td><td><input type="text" name="sTitle" value="<?php echo $sTitle;?>"><br><span style="font-size:11px;">( http://www.abc.com )</span></td></tr>
		<tr><td>Image</td><td><input type="file" name ="slideshow_photo" ><br><span style="font-size:10px;">( Resolution: 980px X 410px )</span><br><input type="hidden" name="OldImage" value="<?php echo $sImage;?>"><img src="../wp-content/themes/softqube/images/slider/<?php echo $sImage;?>" style="width:250px;"></td></tr>
        <tr><td>Sortorder</td><td><input type="text" name="sSortorder" value="<?php echo $sSortorder;?>"></td></tr>
		<tr><td></td><td><input type="submit" name="Update" value="Update" id="html-upload" class="button">  &nbsp;<a  href="options-general.php?page=slideshow_admin" style="text-decoration:none;"><input type="button" name="cancle" value="Cancle" id="html-upload" class="button"></a></td></tr>
	</table>
</form>
<hr>
<?php
}

 
else if(isset($_GET['action']) && ($_GET['action'] == 'add'))
 { 
?><hr>
<form name="upload" action="" method="post" enctype="multipart/form-data">
	<table cellspacing="5" cellpadding="5">
		<tr><td>Title</td><td><input type="text" name="sTitle"><br><span style="font-size:11px;">( http://www.abc.com )</span></td></tr>
		<tr><td>Image</td><td><input type="file" name ="slideshow_photo" ><br><span style="font-size:10px;">( Resolution: 980px X 410px )</span></td></tr>
          <tr><td>Sortorder</td><td><input type="text" name="sSortorder" value=""></td></tr>
		<tr><td></td><td><input type="submit" name="add" value="Add" id="html-upload" class="button">
        &nbsp;<a  href="options-general.php?page=slideshow_admin" style="text-decoration:none;"><input type="button" name="cancle" value="Cancle" id="html-upload" class="button"></a></td></tr>
	</table>
</form>
<?php
}
else
{
?>
<hr>
	<?php if($_GET['msg'] == 2) { ?>
		<h2 class="suc_msg">Your Image Successfully Uploaded</h2>
	<?php } else if($_GET['msg'] == 3) { ?>
		<h2 class="suc_msg">Your Image Successfully Deleted</h2>
	<?php } else if($_GET['msg'] == 1) { ?>
		<h2 class="suc_msg">Your Image Successfully Updated</h2>
	<?php } ?>


<table cellspacing="0" class="wp-list-table widefat fixed pages">
	<thead>
	<tr>
		<th style="width:30px;" class="" id="" scope="col"><span>No</span></th>
		<th style="width:100px;" class="" id="" scope="col"><span>Title</span></th>
		<th style="width:200px;" class="" id="" scope="col"><span>Image</span></th>
        <th style="width:200px;" class="" id="" scope="col"><span>Sortorder</span></th>
		<th style="width:50px;" class="" id="" scope="col"><span>Action</span></th></tr>
	</thead>
	<tbody id="the-list">
<?php
	$i = 1;
	$sqlg = "SELECT * FROM wp_slideshow order by sSortorder ASC";
	$resg = mysql_query($sqlg);
	while($rowg = mysql_fetch_array($resg))
	{	
		$sId = $rowg['sId'];		
		$sImage = $rowg['sImage'];
		
		echo '<tr valign="top">';
		echo '<td>'.$i.'</td>';
		echo '<td>'.$rowg['sTitle'].'</td>';
		echo '<td><img src="../wp-content/themes/softqube/images/slider/'.$rowg['sImage'].'" style="width:250px;"></td>';
		echo '<td>'.$rowg['sSortorder'].'</td>';
		echo '<td><a href="options-general.php?page=slideshow_admin&action=edit&id='.$sId.'" >Edit</a>&nbsp;||&nbsp;<a href="options-general.php?page=slideshow_admin&action=delete&id='.$sId.'" onclick="javascript:return confirm(\'Are You Sure?\')">Delete</a></td>';
		echo '</tr>';
		$i++;
	}	
?>
	</tbody>
</table>
<?php } ?>