-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 18, 2014 at 06:21 AM
-- Server version: 5.6.12
-- PHP Version: 5.4.12

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `home2suites`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_slideshow`
--

CREATE TABLE IF NOT EXISTS `wp_slideshow` (
  `sId` int(11) NOT NULL AUTO_INCREMENT,
  `sImage` varchar(500) NOT NULL,
  `sTitle` varchar(255) NOT NULL,
  `sSortorder` int(11) NOT NULL,
  PRIMARY KEY (`sId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `wp_slideshow`
--

INSERT INTO `wp_slideshow` (`sId`, `sImage`, `sTitle`, `sSortorder`) VALUES
(4, '32527slider-one.png', 'home2suites', 1),
(5, '23452slider-two.png', 'home2suites', 2);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
